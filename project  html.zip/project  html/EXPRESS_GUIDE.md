# Express.js Implementation Guide

## Overview
This currency converter application uses **Node.js** with **Express.js** framework to create a RESTful API backend.

## Express.js Features Used

### 1. **Middleware**
Express middleware functions that execute during the request-response cycle:

- **CORS Middleware**: Enables Cross-Origin Resource Sharing
- **Body Parser**: Parses JSON and URL-encoded request bodies
- **Static Files**: Serves static files (HTML, CSS, JS)
- **Request Logging**: Logs all incoming requests
- **Error Handling**: Centralized error handling middleware

### 2. **Routing**
Express routing system handles different HTTP methods and paths:

```javascript
app.get('/path', handler)    // GET request
app.post('/path', handler)   // POST request
app.put('/path', handler)    // PUT request
app.delete('/path', handler) // DELETE request
```

### 3. **Request & Response Objects**
- `req.body` - Request body data
- `req.params` - Route parameters (`:id`)
- `req.query` - Query string parameters (`?key=value`)
- `req.headers` - HTTP headers
- `res.json()` - Send JSON response
- `res.status()` - Set HTTP status code
- `res.sendFile()` - Send file response

## API Endpoints

### 1. GET `/`
Serves the HTML frontend file.

### 2. GET `/api`
Returns API information and available endpoints.

**Response:**
```json
{
  "name": "Currency Converter API",
  "version": "1.0.0",
  "endpoints": { ... }
}
```

### 3. GET `/api/health`
Health check endpoint to verify server status.

**Response:**
```json
{
  "status": "OK",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "uptime": 123.45,
  "environment": "development"
}
```

### 4. GET `/api/currencies`
Returns list of supported currencies.

**Response:**
```json
{
  "success": true,
  "count": 10,
  "currencies": {
    "USD": "US Dollar",
    "EUR": "Euro",
    ...
  }
}
```

### 5. GET `/api/rates/:from`
Get all exchange rates for a base currency.

**Parameters:**
- `:from` - Base currency code (e.g., USD, EUR)

**Example:** `GET /api/rates/USD`

**Response:**
```json
{
  "success": true,
  "base": "USD",
  "date": "2024-01-01",
  "rates": {
    "EUR": 0.92,
    "GBP": 0.79,
    ...
  }
}
```

### 6. POST `/api/convert`
Convert currency from one to another.

**Request Body:**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "EUR"
}
```

**Response:**
```json
{
  "success": true,
  "originalAmount": 100,
  "convertedAmount": 92,
  "from": "USD",
  "to": "EUR",
  "rate": 0.92,
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

## Error Handling

Express.js error handling with custom error codes:

- **400 Bad Request**: Invalid input, missing fields
- **404 Not Found**: Route doesn't exist
- **500 Internal Server Error**: Server-side errors

All errors return:
```json
{
  "error": "Error message",
  "errorCode": "ERR_CODE",
  "statusCode": 400
}
```

## Express.js Best Practices

1. **Middleware Order**: Middleware executes in order, place error handlers last
2. **Async/Await**: Use async functions for asynchronous operations
3. **Error Handling**: Centralized error handling with try-catch
4. **Status Codes**: Use appropriate HTTP status codes
5. **JSON Responses**: Consistent JSON response format
6. **Request Validation**: Validate input before processing
7. **Environment Variables**: Use `process.env` for configuration

## Running the Server

```bash
# Install dependencies
npm install

# Start server
npm start

# Development mode (with auto-reload)
npm run dev
```

## Express.js Dependencies

- **express**: Web framework for Node.js
- **cors**: Cross-Origin Resource Sharing middleware
- **axios**: HTTP client for API requests

## Project Structure

```
project/
├── server.js          # Express.js server
├── index.html         # Frontend
├── package.json       # Dependencies
└── README.md          # Documentation
```

## Next Steps

To enhance the Express.js server, consider:
- Add authentication middleware
- Implement rate limiting
- Add request validation with Joi or express-validator
- Set up environment variables with dotenv
- Add database integration (MongoDB, PostgreSQL)
- Implement caching with Redis
- Add API documentation with Swagger

