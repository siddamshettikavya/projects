require('dotenv').config();
const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');

// NOTE: Database (MongoDB/Mongoose) has been removed from this build.
// If you want to re-enable DB support later, restore mongoose, config/database, and the Conversion model.

const app = express();
const PORT = process.env.PORT || 3000;

// ============================================
// EXPRESS.JS MIDDLEWARE CONFIGURATION
// ============================================

// CORS - Enable Cross-Origin Resource Sharing
app.use(cors({
    origin: '*', // In production, specify your frontend domain
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Body Parser Middleware - Parse JSON bodies
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Static Files Middleware - Serve static files from current directory
app.use(express.static(__dirname));

// Request Logging Middleware
app.use((req, res, next) => {
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] ${req.method} ${req.path} - IP: ${req.ip}`);
    next();
});

// Error Handling Middleware (must be after routes)
app.use((err, req, res, next) => {
    console.error('Express Error:', err);
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        errorCode: 'ERR_EXPRESS_MIDDLEWARE',
        statusCode: err.status || 500
    });
});

// ============================================
// ROUTES
// ============================================

// Root Route - Serve HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// API Info Route
app.get('/api', (req, res) => {
    res.json({
        name: 'Currency Converter API',
        version: '1.0.0',
        description: 'RESTful API for currency conversion',
        endpoints: {
            'GET /api': 'API information',
            'GET /api/health': 'Health check',
            'GET /api/currencies': 'Get list of supported currencies',
            'GET /api/rates/:from': 'Get exchange rates for a currency',
            'POST /api/convert': 'Convert currency',
            'GET /api/history': 'Get conversion history (disabled)',
            'GET /api/history/:id': 'Get specific conversion by ID (disabled)',
            'DELETE /api/history/:id': 'Delete conversion by ID (disabled)'
        },
        database: 'disabled',
        documentation: 'See README.md for detailed API documentation'
    });
});

// Currency conversion endpoint
app.post('/api/convert', async (req, res) => {
    try {
        const { amount, from, to } = req.body;

        // Validation
        if (!amount || !from || !to) {
            return res.status(400).json({ 
                error: 'Missing required fields: amount, from, to',
                errorCode: 'ERR_MISSING_FIELDS',
                statusCode: 400
            });
        }

        if (isNaN(amount) || amount <= 0) {
            return res.status(400).json({ 
                error: 'Amount must be a positive number',
                errorCode: 'ERR_INVALID_AMOUNT',
                statusCode: 400
            });
        }

        if (from === to) {
            return res.status(400).json({ 
                error: 'From and to currencies cannot be the same',
                errorCode: 'ERR_SAME_CURRENCY',
                statusCode: 400
            });
        }

        // Fetch exchange rates from a free API
        // Using exchangerate-api.com (free tier)
        const apiUrl = `https://api.exchangerate-api.com/v4/latest/${from}`;
        
        try {
            const response = await axios.get(apiUrl);
            const rates = response.data.rates;

            if (!rates[to]) {
                return res.status(400).json({ 
                    error: `Currency ${to} not found in exchange rates`,
                    errorCode: 'ERR_CURRENCY_NOT_FOUND',
                    statusCode: 400
                });
            }

            const rate = rates[to];
            const convertedAmount = amount * rate;

            // No persistence: return conversion result
            res.json({
                success: true,
                originalAmount: amount,
                convertedAmount: convertedAmount,
                from: from,
                to: to,
                rate: rate,
                timestamp: new Date().toISOString(),
                note: 'No database configured; conversion not saved.'
            });
        } catch (apiError) {
            console.error('Exchange rate API error:', apiError.message);
            
            // Fallback: Use hardcoded rates if API fails (for demo purposes)
            const fallbackRates = getFallbackRates(from);
            
            if (!fallbackRates || !fallbackRates[to]) {
                return res.status(500).json({ 
                    error: 'Unable to fetch exchange rates. Please try again later.',
                    errorCode: 'ERR_RATE_FETCH_FAILED',
                    statusCode: 500,
                    details: apiError.message
                });
            }

            const rate = fallbackRates[to];
            const convertedAmount = amount * rate;

            res.json({
                success: true,
                originalAmount: amount,
                convertedAmount: convertedAmount,
                from: from,
                to: to,
                rate: rate,
                timestamp: new Date().toISOString(),
                note: 'Using fallback rates; no database configured.'
            });
        }
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({ 
            error: 'Internal server error',
            errorCode: 'ERR_INTERNAL_SERVER',
            statusCode: 500,
            details: error.message
        });
    }
});

// Fallback exchange rates (approximate rates, update as needed)
function getFallbackRates(baseCurrency) {
    const rates = {
        USD: {
            EUR: 0.92,
            GBP: 0.79,
            JPY: 149.50,
            INR: 83.25,
            AUD: 1.52,
            CAD: 1.36,
            CHF: 0.88,
            CNY: 7.24,
            SGD: 1.34
        },
        EUR: {
            USD: 1.09,
            GBP: 0.86,
            JPY: 162.50,
            INR: 90.50,
            AUD: 1.65,
            CAD: 1.48,
            CHF: 0.96,
            CNY: 7.88,
            SGD: 1.46
        },
        GBP: {
            USD: 1.27,
            EUR: 1.16,
            JPY: 189.00,
            INR: 105.25,
            AUD: 1.92,
            CAD: 1.72,
            CHF: 1.11,
            CNY: 9.15,
            SGD: 1.70
        },
        JPY: {
            USD: 0.0067,
            EUR: 0.0062,
            GBP: 0.0053,
            INR: 0.56,
            AUD: 0.0102,
            CAD: 0.0091,
            CHF: 0.0059,
            CNY: 0.048,
            SGD: 0.0090
        },
        INR: {
            USD: 0.012,
            EUR: 0.011,
            GBP: 0.0095,
            JPY: 1.80,
            AUD: 0.018,
            CAD: 0.016,
            CHF: 0.011,
            CNY: 0.087,
            SGD: 0.016
        },
        AUD: {
            USD: 0.66,
            EUR: 0.61,
            GBP: 0.52,
            JPY: 98.50,
            INR: 54.75,
            CAD: 0.89,
            CHF: 0.58,
            CNY: 4.76,
            SGD: 0.88
        },
        CAD: {
            USD: 0.74,
            EUR: 0.68,
            GBP: 0.58,
            JPY: 110.00,
            INR: 61.25,
            AUD: 1.12,
            CHF: 0.65,
            CNY: 5.33,
            SGD: 0.99
        },
        CHF: {
            USD: 1.14,
            EUR: 1.04,
            GBP: 0.90,
            JPY: 170.00,
            INR: 94.50,
            AUD: 1.73,
            CAD: 1.55,
            CNY: 8.23,
            SGD: 1.53
        },
        CNY: {
            USD: 0.14,
            EUR: 0.13,
            GBP: 0.11,
            JPY: 20.65,
            INR: 11.50,
            AUD: 0.21,
            CAD: 0.19,
            CHF: 0.12,
            SGD: 0.19
        },
        SGD: {
            USD: 0.75,
            EUR: 0.69,
            GBP: 0.59,
            JPY: 111.50,
            INR: 62.25,
            AUD: 1.14,
            CAD: 1.01,
            CHF: 0.66,
            CNY: 5.40
        }
    };

    return rates[baseCurrency];
}

// Health Check Endpoint
app.get('/api/health', async (req, res) => {
    res.json({ 
        status: 'OK', 
        message: 'Currency converter API is running (no database configured)',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        environment: process.env.NODE_ENV || 'development',
        database: {
            status: 'disabled',
            connected: false
        }
    });
});

// Get Supported Currencies
app.get('/api/currencies', (req, res) => {
    const currencies = {
        USD: 'US Dollar',
        EUR: 'Euro',
        GBP: 'British Pound',
        JPY: 'Japanese Yen',
        INR: 'Indian Rupee',
        AUD: 'Australian Dollar',
        CAD: 'Canadian Dollar',
        CHF: 'Swiss Franc',
        CNY: 'Chinese Yuan',
        SGD: 'Singapore Dollar'
    };
    
    res.json({
        success: true,
        count: Object.keys(currencies).length,
        currencies: currencies
    });
});

// Get Exchange Rates for a Currency
app.get('/api/rates/:from', async (req, res) => {
    try {
        const { from } = req.params;
        const fromUpper = from.toUpperCase();

        // Validate currency code
        const validCurrencies = ['USD', 'EUR', 'GBP', 'JPY', 'INR', 'AUD', 'CAD', 'CHF', 'CNY', 'SGD'];
        if (!validCurrencies.includes(fromUpper)) {
            return res.status(400).json({
                error: `Invalid currency code: ${from}`,
                errorCode: 'ERR_INVALID_CURRENCY',
                statusCode: 400,
                validCurrencies: validCurrencies
            });
        }

        const apiUrl = `https://api.exchangerate-api.com/v4/latest/${fromUpper}`;
        
        try {
            const response = await axios.get(apiUrl, { timeout: 5000 });
            const rates = response.data.rates;

            res.json({
                success: true,
                base: fromUpper,
                date: response.data.date || new Date().toISOString().split('T')[0],
                rates: rates,
                timestamp: new Date().toISOString()
            });
        } catch (apiError) {
            console.error('Exchange rate API error:', apiError.message);
            
            // Fallback to hardcoded rates
            const fallbackRates = getFallbackRates(fromUpper);
            
            if (!fallbackRates) {
                return res.status(500).json({
                    error: 'Unable to fetch exchange rates',
                    errorCode: 'ERR_RATE_FETCH_FAILED',
                    statusCode: 500
                });
            }

            res.json({
                success: true,
                base: fromUpper,
                date: new Date().toISOString().split('T')[0],
                rates: fallbackRates,
                timestamp: new Date().toISOString(),
                note: 'Using fallback rates - API unavailable'
            });
        }
    } catch (error) {
        console.error('Server error:', error);
        res.status(500).json({
            error: 'Internal server error',
            errorCode: 'ERR_INTERNAL_SERVER',
            statusCode: 500,
            details: error.message
        });
    }
});

// Database-backed history endpoints removed (database disabled)
app.get('/api/history', (req, res) => {
    res.status(501).json({
        error: 'History endpoint unavailable',
        message: 'Database functionality has been disabled in this deployment'
    });
});

app.get('/api/history/:id', (req, res) => {
    res.status(501).json({
        error: 'History endpoint unavailable',
        message: 'Database functionality has been disabled in this deployment'
    });
});

app.delete('/api/history/:id', (req, res) => {
    res.status(501).json({
        error: 'Delete unavailable',
        message: 'Database functionality has been disabled in this deployment'
    });
});

app.get('/api/history/stats/summary', (req, res) => {
    res.status(501).json({
        error: 'Stats unavailable',
        message: 'Database functionality has been disabled in this deployment'
    });
});

// ============================================
// 404 Handler - Catch all unmatched routes
// ============================================
app.use((req, res) => {
    res.status(404).json({
        error: 'Route not found',
        errorCode: 'ERR_ROUTE_NOT_FOUND',
        statusCode: 404,
        path: req.path,
        method: req.method,
        availableEndpoints: [
            'GET /',
            'GET /api',
            'GET /api/health',
            'GET /api/currencies',
            'GET /api/rates/:from',
            'POST /api/convert',
            'GET /api/history',
            'GET /api/history/:id',
            'GET /api/history/stats/summary',
            'DELETE /api/history/:id'
        ]
    });
});

// ============================================
// START EXPRESS SERVER
// ============================================
// Function to start server with accurate database status
const MAX_PORT_TRIES = 5; // how many alternative ports to try
const PORT_START = Number(process.env.PORT) || 3000;

const startServer = (basePort = PORT_START, attempt = 0) => {
    const port = basePort + attempt;
    const server = app.listen(port, () => {
        // Database disabled in this build
        const isDbConnected = false;

        console.log('='.repeat(50));
        console.log('🚀 Express.js Server Started Successfully!');
        console.log('='.repeat(50));
        console.log(`📍 Server running on: http://localhost:${port}`);
        console.log(`🌐 Environment: ${process.env.NODE_ENV || 'development'}`);
        console.log(`📦 Node.js Version: ${process.version}`);
        console.log('='.repeat(50));
        console.log('📋 Available Endpoints:');
        console.log('   GET  /                    - Frontend UI');
        console.log('   GET  /api                 - API Information');
        console.log('   GET  /api/health          - Health Check');
        console.log('   GET  /api/currencies      - List Currencies');
        console.log('   GET  /api/rates/:from     - Get Exchange Rates');
        console.log('   POST /api/convert         - Convert Currency');
        console.log('   GET  /api/history         - (disabled) Conversion History');
        console.log('   GET  /api/history/:id     - (disabled) Conversion by ID');
        console.log('   GET  /api/history/stats/summary - (disabled) Statistics');
        console.log('   DELETE /api/history/:id   - (disabled) Delete Conversion');
        console.log('='.repeat(50));

        console.log(`💾 Database: ⚠️  Disabled (no MongoDB configured)`);
        console.log(`   💡 App runs in stateless mode; history endpoints are disabled`);
        console.log('='.repeat(50));
    });

    // Handle listen errors, try the next port if in use
    server.on('error', (err) => {
        if (err && err.code === 'EADDRINUSE') {
            console.error('='.repeat(50));
            console.error(`❌ ERROR: Port ${port} is already in use!`);
            console.error('='.repeat(50));

            if (attempt < MAX_PORT_TRIES - 1) {
                const nextPort = basePort + attempt + 1;
                console.warn(`Trying next port: ${nextPort} (attempt ${attempt + 2}/${MAX_PORT_TRIES})`);
                setTimeout(() => startServer(basePort, attempt + 1), 500);
            } else {
                console.error('Exceeded maximum port retry attempts.');
                console.error('💡 Solutions:');
                console.error(`   1. Kill the process using port ${port}:`);
                console.error('      Windows: netstat -ano | findstr :' + port);
                console.error('      Then: taskkill /PID <PID> /F');
                console.error('');
                console.error('   2. Use a different port:');
                console.error('      Create .env file with: PORT=3001');
                console.error('      Or change PORT_START in server.js');
                console.error('='.repeat(50));
                process.exit(1);
            }
        } else {
            console.error('❌ Server Error:', err);
            process.exit(1);
        }
    });
};

// Start server after a brief delay to allow database connection attempt
// This gives MongoDB a chance to connect before we print the status
setTimeout(() => startServer(), 1000);

