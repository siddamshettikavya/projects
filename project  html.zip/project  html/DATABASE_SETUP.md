# Database Setup Guide

## MongoDB Integration

This currency converter application uses **MongoDB** with **Mongoose** ODM to store conversion history.

## Quick Start

### Option 1: Local MongoDB

1. **Install MongoDB:**
   - Windows: Download from https://www.mongodb.com/try/download/community
   - macOS: `brew install mongodb-community`
   - Linux: Follow official installation guide

2. **Start MongoDB Service:**
   ```bash
   # Windows (as Administrator)
   net start MongoDB
   
   # macOS/Linux
   mongod
   ```

3. **Default Connection:**
   - The app will automatically connect to: `mongodb://localhost:27017/currency_converter`
   - No configuration needed!

### Option 2: MongoDB Atlas (Cloud - Free)

1. **Create Account:**
   - Go to https://www.mongodb.com/cloud/atlas
   - Sign up for free account

2. **Create Cluster:**
   - Click "Build a Database"
   - Choose FREE tier (M0)
   - Select your region
   - Create cluster (takes 3-5 minutes)

3. **Get Connection String:**
   - Click "Connect" on your cluster
   - Choose "Connect your application"
   - Copy the connection string
   - Replace `<password>` with your database user password

4. **Create .env File:**
   ```bash
   # Create .env file in project root
   MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/currency_converter?retryWrites=true&w=majority
   PORT=3000
   NODE_ENV=development
   ```

## Database Schema

### Conversion Model

```javascript
{
  originalAmount: Number,      // Original amount
  convertedAmount: Number,    // Converted amount
  fromCurrency: String,       // Source currency (e.g., "USD")
  toCurrency: String,         // Target currency (e.g., "EUR")
  exchangeRate: Number,       // Exchange rate used
  timestamp: Date,            // When conversion occurred
  source: String,             // "api" or "fallback"
  createdAt: Date,            // Auto-generated
  updatedAt: Date             // Auto-generated
}
```

## Features

### Automatic Saving
- Every conversion is automatically saved to the database
- Works seamlessly in the background
- App continues to work even if database save fails

### Conversion History
- View all past conversions
- Filter by currency pairs
- Pagination support
- Statistics and analytics

### Fallback Mode
- If MongoDB is not available, the app works in fallback mode
- Conversions still work, but history is not saved
- No errors or crashes

## API Endpoints

### Get History
```bash
GET /api/history
GET /api/history?limit=10&from=USD&to=EUR
```

### Get Specific Conversion
```bash
GET /api/history/:id
```

### Get Statistics
```bash
GET /api/history/stats/summary
```

### Delete Conversion
```bash
DELETE /api/history/:id
```

## Testing Database Connection

1. **Check Health:**
   ```bash
   curl http://localhost:3000/api/health
   ```
   Look for `"database": { "status": "connected" }`

2. **Make a Conversion:**
   - Use the web interface
   - Check response for `"saved": true`

3. **View History:**
   ```bash
   curl http://localhost:3000/api/history
   ```

## Troubleshooting

### Database Not Connecting

**Error:** `MongoDB Connection Error`

**Solutions:**
1. Check if MongoDB is running:
   ```bash
   # Check MongoDB status
   mongosh --eval "db.adminCommand('ping')"
   ```

2. Verify connection string in `.env` file

3. Check firewall settings

4. For Atlas: Verify IP whitelist and credentials

### App Works But History Not Saving

- Check server console for database errors
- Verify MongoDB connection in health endpoint
- Check database permissions

### Fallback Mode

If you see "Database: Not Connected" in server startup:
- App will work normally
- Conversions won't be saved
- Install MongoDB or configure Atlas to enable history

## Production Recommendations

1. **Use MongoDB Atlas** for production
2. **Set up authentication** for database access
3. **Enable backups** and monitoring
4. **Use environment variables** for connection strings
5. **Add indexes** for better performance (already included)
6. **Set up connection pooling** (Mongoose handles this)

## Indexes

The following indexes are automatically created:
- `timestamp: -1` - For sorting by date
- `fromCurrency: 1, toCurrency: 1` - For filtering by currency pairs

These improve query performance significantly.

