# Expected Output Steps

## Starting the Server

### Step 1: Install Dependencies (First Time Only)
```bash
npm install
```

**Expected Output:**
```
added 150 packages in 30s
```

---

### Step 2: Start the Server
```bash
npm start
```

**Expected Output (With MongoDB Connected):**
```
==================================================
🚀 Express.js Server Started Successfully!
==================================================
📍 Server running on: http://localhost:3000
🌐 Environment: development
📦 Node.js Version: v18.17.0
==================================================
📋 Available Endpoints:
   GET  /                    - Frontend UI
   GET  /api                 - API Information
   GET  /api/health          - Health Check
   GET  /api/currencies      - List Currencies
   GET  /api/rates/:from     - Get Exchange Rates
   POST /api/convert         - Convert Currency
   GET  /api/history         - Get Conversion History
   GET  /api/history/:id     - Get Conversion by ID
   GET  /api/history/stats/summary - Get Statistics
   DELETE /api/history/:id   - Delete Conversion
==================================================
✅ MongoDB Connected: localhost:27017
📊 Database: currency_converter
💾 Database: ✅ Connected
==================================================
```

**Expected Output (Without MongoDB - Fallback Mode):**
```
==================================================
🚀 Express.js Server Started Successfully!
==================================================
📍 Server running on: http://localhost:3000
🌐 Environment: development
📦 Node.js Version: v18.17.0
==================================================
📋 Available Endpoints:
   GET  /                    - Frontend UI
   GET  /api                 - API Information
   GET  /api/health          - Health Check
   GET  /api/currencies      - List Currencies
   GET  /api/rates/:from     - Get Exchange Rates
   POST /api/convert         - Convert Currency
   GET  /api/history         - Get Conversion History
   GET  /api/history/:id     - Get Conversion by ID
   GET  /api/history/stats/summary - Get Statistics
   DELETE /api/history/:id   - Delete Conversion
==================================================
❌ MongoDB Connection Error: connect ECONNREFUSED 127.0.0.1:27017
💡 Make sure MongoDB is running on your system
💡 Or use MongoDB Atlas (cloud) and set MONGODB_URI environment variable
💾 Database: ⚠️  Not Connected (Fallback Mode)
==================================================
```

---

## Testing the Application

### Step 3: Open Browser
Navigate to: `http://localhost:3000`

**Expected:**
- Beautiful currency converter interface loads
- Form with amount, from currency, to currency fields
- Swap button and Convert button visible

---

### Step 4: Make a Conversion
1. Enter amount: `100`
2. Select From: `USD`
3. Select To: `EUR`
4. Click "Convert"

**Expected Output in Browser:**
```
Converted Amount
92.00 EUR
100 USD = 92.00 EUR (Rate: 0.9200)
```

**Expected Server Console Output:**
```
[2024-01-01T12:00:00.000Z] POST /api/convert - IP: ::1
```

**Expected API Response (With Database):**
```json
{
  "success": true,
  "originalAmount": 100,
  "convertedAmount": 92,
  "from": "USD",
  "to": "EUR",
  "rate": 0.92,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "conversionId": "65a1b2c3d4e5f6g7h8i9j0k1",
  "saved": true
}
```

**Expected API Response (Without Database):**
```json
{
  "success": true,
  "originalAmount": 100,
  "convertedAmount": 92,
  "from": "USD",
  "to": "EUR",
  "rate": 0.92,
  "timestamp": "2024-01-01T12:00:00.000Z",
  "conversionId": null,
  "saved": false
}
```

---

## Testing API Endpoints

### Step 5: Test Health Check
```bash
curl http://localhost:3000/api/health
```

**Expected Output:**
```json
{
  "status": "OK",
  "message": "Currency converter API is running",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "uptime": 123.45,
  "environment": "development",
  "database": {
    "status": "connected",
    "connected": true,
    "readyState": 1
  }
}
```

---

### Step 6: Test Conversion History (With Database)
```bash
curl http://localhost:3000/api/history
```

**Expected Output:**
```json
{
  "success": true,
  "count": 5,
  "total": 5,
  "conversions": [
    {
      "_id": "65a1b2c3d4e5f6g7h8i9j0k1",
      "originalAmount": 100,
      "convertedAmount": 92,
      "fromCurrency": "USD",
      "toCurrency": "EUR",
      "exchangeRate": 0.92,
      "timestamp": "2024-01-01T12:00:00.000Z",
      "source": "api",
      "createdAt": "2024-01-01T12:00:00.000Z",
      "updatedAt": "2024-01-01T12:00:00.000Z"
    }
  ]
}
```

**Without Database:**
```json
{
  "error": "Database not connected",
  "errorCode": "ERR_DB_NOT_CONNECTED",
  "statusCode": 503,
  "message": "MongoDB is not available. Please check your database connection."
}
```

---

## Error Scenarios

### Invalid Input
**Request:**
```json
{
  "amount": -100,
  "from": "USD",
  "to": "EUR"
}
```

**Expected Output:**
```json
{
  "error": "Amount must be a positive number",
  "errorCode": "ERR_INVALID_AMOUNT",
  "statusCode": 400
}
```

**Browser Display:**
```
Error Code: ERR_INVALID_AMOUNT HTTP 400
Amount must be a positive number
```

---

### Same Currency
**Request:**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "USD"
}
```

**Expected Output:**
```json
{
  "error": "From and to currencies cannot be the same",
  "errorCode": "ERR_SAME_CURRENCY",
  "statusCode": 400
}
```

---

### Server Not Running
**Browser Error:**
```
Failed to connect to server. Make sure the backend is running.
Error Code: ERR_CONNECTION_FAILED
Details: Failed to fetch
```

---

## Success Indicators

✅ **Server Running:**
- No error messages in console
- Server startup message displayed
- Port 3000 is listening

✅ **Database Connected:**
- "✅ MongoDB Connected" message
- "💾 Database: ✅ Connected" in startup
- Conversions show `"saved": true`

✅ **Application Working:**
- Browser loads without errors
- Conversions complete successfully
- Results display correctly
- No console errors in browser

---

## Troubleshooting Output

### If You See Warnings:
```
[MONGODB DRIVER] Warning: useNewUrlParser is deprecated
```
**Status:** ✅ Fixed - These warnings are now removed

### If You See Errors:
```
❌ MongoDB Connection Error
```
**Status:** ⚠️ Normal - App works in fallback mode

### If Server Won't Start:
```
Error: listen EADDRINUSE: address already in use :::3000
```
**Solution:** Change PORT in `.env` file or stop other process

---

## Next Steps After Successful Start

1. ✅ Server is running
2. ✅ Open browser to `http://localhost:3000`
3. ✅ Test currency conversion
4. ✅ Check conversion history (if database connected)
5. ✅ Test API endpoints
6. ✅ Verify error handling works

Your application is ready to use! 🎉

