# Fix Port 3000 Already in Use Error

## Quick Fix (Windows PowerShell)

### Step 1: Find Process Using Port 3000
```powershell
netstat -ano | findstr :3000
```

### Step 2: Kill the Process
```powershell
taskkill /PID <PID_NUMBER> /F
```

**Example:**
```powershell
taskkill /PID 24024 /F
```

### Step 3: Start Your Server
```powershell
npm start
```

---

## Alternative: Use Different Port

### Option 1: Create .env File
Create a file named `.env` in your project root:
```
PORT=3001
```

### Option 2: Change Port in Code
Edit `server.js`:
```javascript
const PORT = process.env.PORT || 3001;  // Changed from 3000 to 3001
```

**Don't forget to update `index.html`:**
Change the API URL from:
```javascript
const response = await fetch('http://localhost:3000/api/convert', {
```
To:
```javascript
const response = await fetch('http://localhost:3001/api/convert', {
```

---

## One-Line Solution (PowerShell)

Kill all Node.js processes:
```powershell
Get-Process node | Stop-Process -Force
```

**Warning:** This kills ALL Node.js processes, not just your server!

---

## Prevent Future Issues

1. **Always stop server properly:**
   - Press `Ctrl+C` in the terminal where server is running
   - Don't just close the terminal window

2. **Check before starting:**
   ```powershell
   netstat -ano | findstr :3000
   ```
   If you see output, port is in use

3. **Use different port for development:**
   - Use port 3001, 3002, etc. for other projects

---

## Common Causes

- Previous server instance still running
- Another application using port 3000
- Server crashed but process didn't terminate
- Multiple terminal windows with server running

---

## Verify Server is Running

After starting, check:
```powershell
netstat -ano | findstr :3000
```

You should see:
```
TCP    0.0.0.0:3000           0.0.0.0:0              LISTENING       <PID>
```

Then open browser: `http://localhost:3000`

