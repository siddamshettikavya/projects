# Currency Converter

A modern, full-stack currency converter application with a beautiful HTML frontend and Node.js/Express backend.

## Features

- 💱 Convert between multiple currencies (USD, EUR, GBP, JPY, INR, AUD, CAD, CHF, CNY, SGD)
- 🔄 Swap currencies with one click
- 📊 Real-time exchange rates
- 🎨 Modern, responsive UI
- ⚡ Fast and reliable conversion
- 💾 **Database Integration** - MongoDB for storing conversion history
- 📜 **Conversion History** - View and manage past conversions
- 📈 **Statistics** - Track conversion patterns

## Prerequisites

- Node.js (v14 or higher)
- npm (Node Package Manager)
- MongoDB (local installation or MongoDB Atlas account)

## Installation

1. Install dependencies:
```bash
npm install
```

2. **Database Setup:**

   **Option A: Local MongoDB**
   - Install MongoDB on your system: https://www.mongodb.com/try/download/community
   - Start MongoDB service
   - Default connection: `mongodb://localhost:27017/currency_converter`

   **Option B: MongoDB Atlas (Cloud)**
   - Create a free account at https://www.mongodb.com/cloud/atlas
   - Create a cluster and get your connection string
   - Create a `.env` file in the project root:
   ```
   MONGODB_URI=your_mongodb_atlas_connection_string
   PORT=3000
   NODE_ENV=development
   ```

   **Note:** The application works in fallback mode without MongoDB, but conversion history won't be saved.

## Running the Application

1. Start the backend server:
```bash
npm start
```

Or for development with auto-reload:
```bash
npm run dev
```

2. Open your browser and navigate to:
```
http://localhost:3000
```

## API Endpoints

### POST /api/convert
Convert currency from one to another.

**Request Body:**
```json
{
  "amount": 100,
  "from": "USD",
  "to": "EUR"
}
```

**Response:**
```json
{
  "success": true,
  "originalAmount": 100,
  "convertedAmount": 92,
  "from": "USD",
  "to": "EUR",
  "rate": 0.92,
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

### GET /api/health
Health check endpoint with database status.

**Response:**
```json
{
  "status": "OK",
  "message": "Currency converter API is running",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "uptime": 123.45,
  "environment": "development",
  "database": {
    "status": "connected",
    "connected": true
  }
}
```

### GET /api/history
Get conversion history (requires database).

**Query Parameters:**
- `limit` - Number of results (default: 50)
- `skip` - Number of results to skip (default: 0)
- `from` - Filter by source currency
- `to` - Filter by target currency

**Example:** `GET /api/history?limit=10&from=USD`

**Response:**
```json
{
  "success": true,
  "count": 10,
  "total": 150,
  "conversions": [...]
}
```

### GET /api/history/:id
Get a specific conversion by ID.

### GET /api/history/stats/summary
Get conversion statistics.

**Response:**
```json
{
  "success": true,
  "stats": {
    "totalConversions": 150,
    "mostConvertedFrom": { "_id": "USD", "count": 45 },
    "mostConvertedTo": { "_id": "EUR", "count": 60 }
  }
}
```

### DELETE /api/history/:id
Delete a conversion by ID.

## Technologies Used

- **Frontend:** HTML5, CSS3, JavaScript (Vanilla)
- **Backend:** Node.js, Express.js
- **Database:** MongoDB with Mongoose ODM
- **API:** exchangerate-api.com (with fallback rates)
- **Environment:** dotenv for configuration

## Project Structure

```
currency-converter/
├── index.html           # Frontend HTML file
├── server.js            # Backend Express server
├── package.json         # Node.js dependencies
├── .env.example         # Environment variables template
├── .gitignore           # Git ignore file
├── config/
│   └── database.js      # MongoDB connection configuration
├── models/
│   └── Conversion.js    # Mongoose schema for conversions
└── README.md            # This file
```

## Notes

- The application uses a free exchange rate API (exchangerate-api.com)
- If the API is unavailable, the application falls back to hardcoded exchange rates
- Exchange rates are approximate and should be updated regularly for production use

## License

ISC

