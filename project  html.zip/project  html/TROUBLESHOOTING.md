# Troubleshooting Guide

## Common Errors and Solutions

### 1. "Cannot find module 'dotenv'"
**Error:**
```
Error: Cannot find module 'dotenv'
```

**Solution:**
```bash
npm install
```
This will install all required dependencies including `dotenv`, `mongoose`, etc.

---

### 2. "Cannot find module './config/database'"
**Error:**
```
Error: Cannot find module './config/database'
```

**Solution:**
- Make sure the `config` folder exists with `database.js` file
- Check file structure:
  ```
  project/
  ├── config/
  │   └── database.js
  ├── models/
  │   └── Conversion.js
  └── server.js
  ```

---

### 3. "MongoDB Connection Error"
**Error:**
```
❌ MongoDB Connection Error: connect ECONNREFUSED 127.0.0.1:27017
```

**Solutions:**

**Option A: Install and Start MongoDB Locally**
- Install MongoDB: https://www.mongodb.com/try/download/community
- Start MongoDB service:
  ```bash
  # Windows
  net start MongoDB
  
  # macOS/Linux
  mongod
  ```

**Option B: Use MongoDB Atlas (Cloud)**
- Create free account at https://www.mongodb.com/cloud/atlas
- Get connection string
- Create `.env` file:
  ```
  MONGODB_URI=your_connection_string_here
  ```

**Option C: Run Without Database**
- The app works in fallback mode without MongoDB
- Conversions will work but history won't be saved
- This is normal and expected

---

### 4. "Port 3000 already in use"
**Error:**
```
Error: listen EADDRINUSE: address already in use :::3000
```

**Solutions:**

**Option A: Use Different Port**
Create `.env` file:
```
PORT=3001
```

**Option B: Stop Other Process**
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID <PID> /F

# macOS/Linux
lsof -ti:3000 | xargs kill
```

---

### 5. "ERR_DB_NOT_CONNECTED" in API Response
**Error:**
```json
{
  "error": "Database not connected",
  "errorCode": "ERR_DB_NOT_CONNECTED",
  "statusCode": 503
}
```

**Solution:**
- This is expected if MongoDB is not running
- The app works in fallback mode
- To enable database features:
  1. Install/start MongoDB
  2. Or configure MongoDB Atlas
  3. Restart the server

---

### 6. "ERR_CONNECTION_FAILED" in Frontend
**Error:**
```
Failed to connect to server. Make sure the backend is running.
```

**Solutions:**
1. **Check if server is running:**
   ```bash
   npm start
   ```

2. **Check server URL in index.html:**
   - Make sure it matches your server port
   - Default: `http://localhost:3000`

3. **Check CORS settings:**
   - Server should allow requests from your frontend origin

---

### 7. "ERR_MISSING_FIELDS"
**Error:**
```json
{
  "error": "Missing required fields: amount, from, to",
  "errorCode": "ERR_MISSING_FIELDS",
  "statusCode": 400
}
```

**Solution:**
- Make sure request body includes:
  ```json
  {
    "amount": 100,
    "from": "USD",
    "to": "EUR"
  }
  ```

---

### 8. "ERR_RATE_FETCH_FAILED"
**Error:**
```json
{
  "error": "Unable to fetch exchange rates",
  "errorCode": "ERR_RATE_FETCH_FAILED",
  "statusCode": 500
}
```

**Solution:**
- The app will use fallback rates automatically
- Check internet connection
- The external API might be temporarily unavailable
- App continues to work with fallback rates

---

### 9. Module Import Errors
**Error:**
```
SyntaxError: Cannot use import statement outside a module
```

**Solution:**
- Make sure you're using `require()` not `import`
- This is a CommonJS project, not ES6 modules
- Check all files use `require()` syntax

---

### 10. Database Schema Errors
**Error:**
```
TypeError: Cannot read property 'create' of undefined
```

**Solution:**
- Make sure `Conversion` model is properly imported
- Check `models/Conversion.js` exists and exports correctly
- Verify database connection before using models

---

## Quick Fixes Checklist

- [ ] Run `npm install` to install dependencies
- [ ] Check MongoDB is running (if using database)
- [ ] Verify `.env` file exists (if using MongoDB Atlas)
- [ ] Check server is running on correct port
- [ ] Verify all files are in correct folders
- [ ] Check console for specific error messages
- [ ] Restart the server after changes

## Getting Help

1. **Check Server Console:**
   - Look for error messages in terminal
   - Check for stack traces

2. **Check Browser Console:**
   - Open Developer Tools (F12)
   - Look for JavaScript errors
   - Check Network tab for failed requests

3. **Test API Endpoints:**
   ```bash
   # Health check
   curl http://localhost:3000/api/health
   
   # Test conversion
   curl -X POST http://localhost:3000/api/convert \
     -H "Content-Type: application/json" \
     -d '{"amount":100,"from":"USD","to":"EUR"}'
   ```

4. **Verify Installation:**
   ```bash
   node --version  # Should be v14 or higher
   npm --version
   ```

## Still Having Issues?

1. Delete `node_modules` and reinstall:
   ```bash
   rm -rf node_modules
   npm install
   ```

2. Check Node.js version compatibility
3. Review error messages carefully
4. Check file permissions
5. Verify all environment variables are set correctly

